# Scrolling Text Animation

A Pen created on CodePen.

Original URL: [https://codepen.io/MausamiK/pen/VYwbOoL](https://codepen.io/MausamiK/pen/VYwbOoL).

